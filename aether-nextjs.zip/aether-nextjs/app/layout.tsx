import type { Metadata } from "next";
import { Inter, Instrument_Serif } from "next/font/google";
import SmoothScroll from "@/components/providers/SmoothScroll";
import Cursor from "@/components/ui/Cursor";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const instrument = Instrument_Serif({
  subsets: ["latin"],
  weight: "400",
  style: ["normal", "italic"],
  variable: "--font-instrument",
  display: "swap",
});

export const metadata: Metadata = {
  title: "AETHER — The AI Operating Layer",
  description:
    "Aether deploys autonomous agents across your stack — triaging, drafting, shipping — while your team focuses on what only humans can do.",
  openGraph: {
    title: "AETHER — The AI Operating Layer",
    description: "Autonomous agents for teams that move at the speed of thought.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "AETHER — The AI Operating Layer",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${instrument.variable}`}>
      <body className="bg-bg text-ink antialiased overflow-x-hidden">
        <SmoothScroll>
          <Cursor />
          {children}
        </SmoothScroll>
      </body>
    </html>
  );
}
