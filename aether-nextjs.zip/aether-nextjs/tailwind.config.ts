import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#050507",
        bg2: "#0a0a11",
        ink: "#f2f2f6",
        mut: "rgba(233,233,244,.55)",
        dim: "rgba(233,233,244,.34)",
        line: "rgba(255,255,255,.08)",
        line2: "rgba(255,255,255,.14)",
        violet: "#7c5cff",
        cyan: "#3ad6ff",
        magenta: "#ff4ecd",
        mint: "#2fe6a7",
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        serif: ["var(--font-instrument)", "Georgia", "serif"],
      },
      backgroundImage: {
        grad: "linear-gradient(100deg,#7c5cff,#3ad6ff 55%,#ff4ecd)",
      },
      transitionTimingFunction: {
        out4: "cubic-bezier(.22,1,.36,1)",
      },
    },
  },
  plugins: [],
};
export default config;
