# AETHER — The AI Operating Layer

A cinematic, Awwwards-style marketing site for a fictional AI SaaS. Built with
Next.js 14 (App Router), TypeScript, Tailwind CSS, Framer Motion, GSAP ScrollTrigger,
Lenis smooth scroll, and React Three Fiber.

## Quickstart

```bash
npm install
npm run dev        # http://localhost:3000
```

```bash
npm run build      # production build
npm run typecheck  # tsc --noEmit
```

## What's inside

| Layer | Tech |
| --- | --- |
| Framework | Next.js 14, React 18, TypeScript (strict) |
| Styling | Tailwind CSS + design tokens (`tailwind.config.ts`) |
| Motion | Framer Motion (reveals, springs, counters) + GSAP ScrollTrigger (pinned horizontal section, manifesto scrub, footer parallax) |
| Smooth scroll | Lenis, synced to ScrollTrigger in `components/providers/SmoothScroll.tsx` |
| 3D | React Three Fiber — torus-knot artifact, wireframe ghost, additive particle field, mouse-parallax camera (`components/three/HeroScene.tsx`) |

## Signature interactions

- Preloader with counter → clip reveal → staggered hero line masks
- Custom cursor (instant dot + trailing spring ring, grows over interactive elements)
- Magnetic buttons with spring physics
- Word-by-word manifesto illumination on scroll
- Bento grid with cursor spotlight + border shimmer
- Pinned **horizontal** "How it works" journey (desktop; stacks vertically on mobile)
- Dashboard preview with 3D perspective tilt, animated chart draw, live activity feed
- Velocity-styled dual testimonial marquees (hover to pause)
- Pricing toggle with animated numbers
- Reduced-motion safe: honors `prefers-reduced-motion` everywhere

## Where to edit

- **All copy/content** → `lib/data.ts`
- **Design tokens** → `tailwind.config.ts` + `app/globals.css`
- **Sections** → `components/sections/*` (one file per section, composed in `app/page.tsx`)

## Notes

- The hero 3D scene is dynamically imported with `ssr: false` and degrades gracefully.
- SEO metadata (OpenGraph/Twitter) lives in `app/layout.tsx`.
- All logos, companies, testimonials, and metrics are fictional.
