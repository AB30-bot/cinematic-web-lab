export const NAV_LINKS = [
  { label: "Product", href: "#features" },
  { label: "How it works", href: "#how" },
  { label: "Platform", href: "#dashboard" },
  { label: "Pricing", href: "#pricing" },
];

export const LOGOS = [
  { name: "ARCLIGHT", style: "default" },
  { name: "bluenote", style: "thin" },
  { name: "SOLSTICE", style: "wide" },
  { name: "north/loop", style: "mono" },
  { name: "KOVA", style: "default" },
  { name: "driftwood", style: "thin" },
  { name: "MERIDIAN", style: "wide" },
  { name: "fable.dev", style: "mono" },
] as const;

export const MANIFESTO: { text: string; accent?: boolean }[] = [
  { text: "Your team wasn't hired to chase tickets, babysit pipelines, or drown in threads. Aether gives every team an" },
  { text: "autonomous workforce", accent: true },
  { text: "— so humans can get back to the" },
  { text: "thinking.", accent: true },
];

export const STEPS = [
  {
    num: "01",
    title: "Connect your stack",
    body: "One-click integrations for the 80+ tools your team lives in. Aether maps your workflows in minutes — no consultants, no migrations.",
    points: ["Slack, Linear, GitHub, Notion, Gmail…", "Read-only until you say otherwise"],
  },
  {
    num: "02",
    title: "Teach it your playbook",
    body: "Show an agent a task once — or just describe it. Aether learns your tone, your edge cases, your definition of done.",
    points: ["Natural-language playbooks, versioned like code", "Dry-run mode before anything ships"],
  },
  {
    num: "03",
    title: "Delegate, then sleep",
    body: "Agents run around the clock. You wake up to finished work, a clean queue, and a morning digest of everything that happened.",
    points: ["Full audit trail of every action", "Roll back anything with one click"],
  },
];

export const STATS = [
  { value: 12400, suffix: "+", label: "Teams running on Aether" },
  { value: 38, suffix: "M", label: "Agent runs every month" },
  { value: 40, suffix: "hrs", label: "Saved per team, weekly" },
  { value: 99.99, suffix: "%", dec: 2, label: "Uptime, globally distributed" },
];

export const TESTIMONIALS_A = [
  { quote: "We deleted four internal tools the month we adopted Aether. The triage agent alone pays for the whole plan.", name: "Mira Chen", role: "VP Engineering, Arclight", initials: "MC", from: "#7c5cff", to: "#3ad6ff" },
  { quote: "It's the first AI product that feels like hiring, not prompting. Our agents have quarterly goals now. I'm not joking.", name: "Dele Okafor", role: "COO, Northloop", initials: "DO", from: "#ff4ecd", to: "#7c5cff" },
  { quote: "Support backlog went from 3 days to 40 minutes. Our CSAT is the highest it's ever been — with a smaller team.", name: "Sofia Reyes", role: "Head of Support, Bluenote", initials: "SR", from: "#3ad6ff", to: "#2fe6a7" },
  { quote: "The audit trail sold our security team. The morning digest sold everyone else. Rollout took one afternoon.", name: "Jonas Thal", role: "CISO, Meridian Co", initials: "JT", from: "#febc2e", to: "#ff4ecd" },
];

export const TESTIMONIALS_B = [
  { quote: "I was the bottleneck for every release note, every changelog, every update email. I am no longer the bottleneck.", name: "Amara Kide", role: "Product Lead, Solstice", initials: "AK", from: "#2fe6a7", to: "#3ad6ff" },
  { quote: "Aether's dry-run mode is genius. We watched it work for a week before flipping the switch. Zero surprises since.", name: "Luca Bianchi", role: "CTO, Driftwood", initials: "LB", from: "#7c5cff", to: "#ff4ecd" },
  { quote: "40 hours a week back. That's not a metric, that's a whole engineer. We put it toward the roadmap.", name: "Priya Wells", role: "Founder, Kova", initials: "PW", from: "#3ad6ff", to: "#7c5cff" },
  { quote: "Our onboarding agent greets every new hire, provisions access, and schedules their first week. HR cried. Happy tears.", name: "Hana Nakamura", role: "People Ops, Fable.dev", initials: "HN", from: "#ff4ecd", to: "#febc2e" },
];

export const PLANS = [
  {
    name: "Starter",
    desc: "For solo builders & side projects",
    monthly: 0,
    annual: 0,
    noteMo: "Free forever",
    noteYr: "Free forever",
    cta: "Start free",
    popular: false,
    check: "#7c5cff",
    features: ["2 autonomous agents", "500 agent runs / month", "10 integrations", "Community support"],
  },
  {
    name: "Scale",
    desc: "For teams shipping every week",
    monthly: 29,
    annual: 23,
    noteMo: "Billed monthly",
    noteYr: "Billed annually — 2 months free",
    cta: "Start 14-day trial",
    popular: true,
    check: "#3ad6ff",
    features: ["Unlimited agents", "25,000 agent runs / month", "All 80+ integrations", "Unified memory across tools", "Priority support, 4h SLA"],
  },
  {
    name: "Enterprise",
    desc: "For orgs with serious surface area",
    monthly: null,
    annual: null,
    noteMo: "Volume pricing, annual terms",
    noteYr: "Volume pricing, annual terms",
    cta: "Talk to sales",
    popular: false,
    check: "#ff4ecd",
    features: ["Unlimited everything", "On-prem or region-pinned inference", "SSO/SAML, SCIM, custom RBAC", "Dedicated success engineer"],
  },
];

export const FEED = [
  { icon: "🔀", bg: "rgba(124,92,255,.2)", who: "Triage-01", what: "routed 12 tickets to eng", when: "just now" },
  { icon: "✍️", bg: "rgba(58,214,255,.15)", who: "Scribe", what: "drafted onboarding doc v3", when: "2m ago" },
  { icon: "📊", bg: "rgba(255,78,205,.15)", who: "Analyst", what: "flagged churn anomaly", when: "8m ago" },
  { icon: "✅", bg: "rgba(47,230,167,.15)", who: "QA-Loop", what: "verified 214 test runs", when: "14m ago" },
  { icon: "🌙", bg: "rgba(255,255,255,.08)", who: "Night shift", what: "completed 96 tasks", when: "6h ago" },
];

export const KPIS = [
  { label: "Active agents", value: 24, delta: "▲ 4 this week" },
  { label: "Tasks today", value: 1284, delta: "▲ 12.4%" },
  { label: "Hours saved", value: 312, delta: "▲ this week" },
];
