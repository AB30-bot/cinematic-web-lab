import { clsx, type ClassValue } from "clsx";

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function fmt(v: number, dec = 0): string {
  if (dec) return v.toFixed(dec);
  return Math.round(v).toLocaleString("en-US");
}
