"use client";

import { useEffect, useState } from "react";
import { animate } from "framer-motion";
import { fmt } from "@/lib/utils";

/** Animated number that counts up when `start` flips true. */
export default function Counter({
  to,
  dec = 0,
  duration = 1.8,
  start = true,
}: {
  to: number;
  dec?: number;
  duration?: number;
  start?: boolean;
}) {
  const [text, setText] = useState("0");

  useEffect(() => {
    if (!start) return;
    const controls = animate(0, to, {
      duration,
      ease: "easeOut",
      onUpdate: (v) => setText(fmt(v, dec)),
    });
    return () => controls.stop();
  }, [start, to, dec, duration]);

  return <>{text}</>;
}
