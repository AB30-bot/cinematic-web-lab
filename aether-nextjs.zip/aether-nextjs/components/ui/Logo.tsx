let uid = 0;

export default function Logo({ className }: { className?: string }) {
  const id = `lg-${uid++}`;
  return (
    <svg viewBox="0 0 48 48" fill="none" className={className}>
      <path d={"M24 4 L44 40 L4 40 Z"} stroke={`url(#${id})`} strokeWidth="3" strokeLinejoin="round" />
      <circle cx="24" cy="28" r="5" fill={`url(#${id})`} />
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="48" y2="48">
          <stop stopColor="#7c5cff" />
          <stop offset=".55" stopColor="#3ad6ff" />
          <stop offset="1" stopColor="#ff4ecd" />
        </linearGradient>
      </defs>
    </svg>
  );
}
