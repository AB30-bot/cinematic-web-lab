"use client";

import { useRef, type ReactNode, type MouseEvent } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { cn } from "@/lib/utils";

type Props = {
  children: ReactNode;
  href?: string;
  variant?: "primary" | "ghost";
  size?: "md" | "sm";
  className?: string;
};

/** Button that leans toward the cursor with spring physics. */
export default function MagneticButton({
  children,
  href = "#",
  variant = "primary",
  size = "md",
  className,
}: Props) {
  const ref = useRef<HTMLAnchorElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 160, damping: 14, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 160, damping: 14, mass: 0.4 });

  const onMouseMove = (e: MouseEvent) => {
    const r = ref.current!.getBoundingClientRect();
    x.set((e.clientX - (r.left + r.width / 2)) * 0.32);
    y.set((e.clientY - (r.top + r.height / 2)) * 0.32);
  };
  const reset = () => { x.set(0); y.set(0); };

  return (
    <motion.a
      ref={ref}
      href={href}
      data-hover
      onMouseMove={onMouseMove}
      onMouseLeave={reset}
      style={{ x: sx, y: sy }}
      className={cn(
        "btn-base group",
        size === "md" ? "px-7 py-3.5 text-[14.5px]" : "px-5 py-2.5 text-[13.5px]",
        variant === "primary" &&
          "bg-ink text-[#0a0a0f] hover:text-white hover:shadow-[0_12px_44px_-8px_rgba(124,92,255,.55)] before:absolute before:inset-0 before:-z-10 before:rounded-full before:bg-grad before:opacity-0 before:transition-opacity before:duration-500 hover:before:opacity-100",
        variant === "ghost" &&
          "border border-line2 bg-white/[.02] text-ink hover:border-white/30 hover:bg-white/5",
        className
      )}
    >
      {children}
    </motion.a>
  );
}
