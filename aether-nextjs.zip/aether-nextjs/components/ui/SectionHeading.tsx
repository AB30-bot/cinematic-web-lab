import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import Reveal from "./Reveal";

export default function SectionHeading({
  kicker,
  title,
  sub,
  center,
}: {
  kicker: string;
  title: ReactNode;
  sub?: string;
  center?: boolean;
}) {
  return (
    <div className={cn("mb-14 max-w-3xl md:mb-20", center && "mx-auto text-center")}>
      <div className={cn("kicker mb-5", center && "after:h-px after:w-6 after:bg-grad")}>{kicker}</div>
      <Reveal>
        <h2 className="text-[clamp(34px,4.6vw,60px)] font-bold leading-[1.08] tracking-[-0.03em]">
          {title}
        </h2>
      </Reveal>
      {sub && (
        <Reveal delay={0.1}>
          <p className={cn("mt-5 max-w-xl text-[clamp(15.5px,1.4vw,18px)] text-mut", center && "mx-auto")}>
            {sub}
          </p>
        </Reveal>
      )}
    </div>
  );
}
