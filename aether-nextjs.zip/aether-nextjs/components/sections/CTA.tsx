import Reveal from "@/components/ui/Reveal";
import MagneticButton from "@/components/ui/MagneticButton";

export default function CTA() {
  return (
    <section className="relative overflow-hidden px-5 py-32 text-center md:px-16 lg:py-48">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-[-40%_-20%] z-0 opacity-50 blur-[70px]"
        style={{
          background:
            "conic-gradient(from 0deg at 50% 50%,transparent 0deg,rgba(124,92,255,.5) 80deg,transparent 160deg,rgba(58,214,255,.35) 230deg,transparent 300deg,rgba(255,78,205,.3) 340deg,transparent 360deg)",
          animation: "aur 24s linear infinite",
        }}
      />
      <div className="relative z-[1] mx-auto max-w-[1240px]">
        <Reveal>
          <h2 className="mx-auto max-w-[900px] text-[clamp(40px,6.4vw,88px)] font-bold leading-[1.05] tracking-[-.035em]">
            Give your team their <em className="grad-text font-serif italic">time</em> back.
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mx-auto mt-6 max-w-[520px] text-[17px] text-mut">
            Join 12,000+ teams who stopped doing robot work. Your first agent can be live before your
            coffee cools.
          </p>
        </Reveal>
        <Reveal delay={0.18}>
          <div className="mt-11 flex flex-wrap justify-center gap-4">
            <MagneticButton href="#">
              Start building free <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
            </MagneticButton>
            <MagneticButton href="#" variant="ghost">Book a demo</MagneticButton>
          </div>
          <div className="mt-5 text-[12.5px] text-dim">No credit card · Cancel anytime · SOC 2 Type II</div>
        </Reveal>
      </div>
    </section>
  );
}
