import SectionHeading from "@/components/ui/SectionHeading";
import { TESTIMONIALS_A, TESTIMONIALS_B } from "@/lib/data";

type T = (typeof TESTIMONIALS_A)[number];

function Card({ t }: { t: T }) {
  return (
    <div className="glass-card w-[320px] shrink-0 p-6 transition-colors duration-500 hover:border-violet/40 hover:bg-violet/5 md:w-[400px]">
      <div className="mb-3.5 text-[13px] tracking-[3px] text-violet">★★★★★</div>
      <p className="text-[14.5px] leading-[1.65] text-[rgba(233,233,244,.78)]">&ldquo;{t.quote}&rdquo;</p>
      <div className="mt-5 flex items-center gap-3">
        <div
          className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full text-xs font-bold text-white"
          style={{ background: `linear-gradient(135deg,${t.from},${t.to})` }}
        >
          {t.initials}
        </div>
        <div>
          <b className="block text-[13.5px] font-semibold">{t.name}</b>
          <span className="text-xs text-dim">{t.role}</span>
        </div>
      </div>
    </div>
  );
}

function Row({ items, reverse }: { items: T[]; reverse?: boolean }) {
  const doubled = [...items, ...items];
  return (
    <div className="mb-4 overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_8%,#000_92%,transparent)]">
      <div
        className={`marquee-track flex w-max gap-4 p-1 ${reverse ? "marquee-reverse" : ""}`}
        style={{ "--marq-duration": "46s" } as React.CSSProperties}
      >
        {doubled.map((t, i) => <Card key={i} t={t} />)}
      </div>
    </div>
  );
}

export default function Testimonials() {
  return (
    <section className="overflow-hidden py-24 lg:py-40">
      <div className="px-6">
        <SectionHeading
          center
          kicker="Loved by builders"
          title={<>Don&apos;t take our <em className="grad-text font-serif italic">word</em> for it.</>}
        />
      </div>
      <Row items={TESTIMONIALS_A} />
      <Row items={TESTIMONIALS_B} reverse />
    </section>
  );
}
