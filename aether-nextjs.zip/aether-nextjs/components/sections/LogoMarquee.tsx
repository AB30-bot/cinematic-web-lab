import { LOGOS } from "@/lib/data";
import { cn } from "@/lib/utils";

const styleMap: Record<string, string> = {
  default: "font-bold tracking-[.06em] text-xl",
  thin: "font-serif italic text-[23px]",
  wide: "font-semibold tracking-[.42em] text-base",
  mono: "font-mono font-medium tracking-[-.02em] text-lg",
};

export default function LogoMarquee() {
  const items = [...LOGOS, ...LOGOS];
  return (
    <section className="border-y border-line bg-white/[.012] py-14">
      <div className="mb-8 text-center text-[11.5px] uppercase tracking-[.3em] text-dim">
        Trusted by 12,000+ teams shipping the future
      </div>
      <div className="overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_12%,#000_88%,transparent)]">
        <div className="marquee-track flex w-max" style={{ "--marq-duration": "34s" } as React.CSSProperties}>
          {items.map((logo, i) => (
            <span
              key={i}
              className={cn(
                "whitespace-nowrap px-11 text-dim grayscale transition-colors duration-500 hover:text-mut",
                styleMap[logo.style]
              )}
            >
              {logo.name}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
