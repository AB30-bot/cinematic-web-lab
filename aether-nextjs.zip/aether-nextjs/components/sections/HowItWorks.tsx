"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { STEPS } from "@/lib/data";

gsap.registerPlugin(ScrollTrigger);

const Check = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" className="mt-1 shrink-0">
    <path d="M20 6L9 17l-5-5" stroke="#3ad6ff" strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

/** Pinned horizontal journey — scrolling drives the rail sideways (desktop). */
export default function HowItWorks() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const mm = gsap.matchMedia();
      mm.add("(min-width: 901px) and (prefers-reduced-motion: no-preference)", () => {
        const rail = railRef.current!;
        const amt = () => rail.scrollWidth - window.innerWidth;
        gsap.to(rail, {
          x: () => -amt(),
          ease: "none",
          scrollTrigger: {
            trigger: wrapRef.current,
            start: "top top",
            end: () => `+=${amt()}`,
            pin: true,
            scrub: 1,
            invalidateOnRefresh: true,
            onUpdate: (self) => {
              if (barRef.current) barRef.current.style.transform = `scaleX(${self.progress})`;
            },
          },
        });
      });
    }, wrapRef);
    return () => ctx.revert();
  }, []);

  return (
    <section id="how">
      <div ref={wrapRef} className="relative overflow-hidden">
        <div ref={railRef} className="flex w-max max-md:block max-md:w-auto">
          {STEPS.map((step) => (
            <div
              key={step.num}
              className="flex w-screen shrink-0 items-center justify-center px-6 py-28 md:min-h-svh md:px-20 max-md:w-auto"
            >
              <div className="grid max-w-[1240px] items-center gap-10 md:grid-cols-2 md:gap-24">
                <div>
                  <div
                    className="text-[clamp(120px,18vw,240px)] font-extrabold leading-[.9] tracking-[-.06em] text-transparent [background-clip:text] [-webkit-background-clip:text]"
                    style={{ backgroundImage: "linear-gradient(180deg,rgba(255,255,255,.16),rgba(255,255,255,.02))" }}
                  >
                    {step.num}
                    <span className="grad-text align-super text-[.32em] tracking-[-.02em]">/03</span>
                  </div>
                  <h3 className="mb-5 mt-4 text-[clamp(30px,3.6vw,48px)] font-bold leading-[1.1] tracking-[-.03em]">
                    {step.title}
                  </h3>
                  <p className="max-w-[460px] text-[clamp(15px,1.4vw,17.5px)] text-mut">{step.body}</p>
                  <div className="mt-7 flex flex-col gap-3">
                    {step.points.map((pt) => (
                      <span key={pt} className="flex items-start gap-3 text-sm text-mut">
                        <Check /> {pt}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="glass-card relative flex aspect-[1.15] items-center justify-center rounded-3xl">
                  <div
                    aria-hidden
                    className="absolute inset-0"
                    style={{ background: "radial-gradient(60% 60% at 50% 40%,rgba(124,92,255,.16),transparent 70%)" }}
                  />
                  <div className="grad-text relative text-[clamp(60px,8vw,110px)] font-extrabold opacity-80">
                    {step.num}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="absolute bottom-11 left-1/2 z-[5] hidden -translate-x-1/2 items-center gap-3.5 text-[11px] tracking-[.26em] text-dim md:flex">
          <span>01</span>
          <div className="relative h-px w-[200px] bg-line2">
            <div ref={barRef} className="absolute inset-0 origin-left scale-x-0 bg-grad" />
          </div>
          <span>03</span>
        </div>
      </div>
    </section>
  );
}
