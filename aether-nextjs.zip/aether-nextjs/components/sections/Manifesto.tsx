"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { MANIFESTO } from "@/lib/data";
import { cn } from "@/lib/utils";

gsap.registerPlugin(ScrollTrigger);

/** Words illuminate one-by-one as you scroll through. */
export default function Manifesto() {
  const ref = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.to(".manifesto-word", {
        opacity: 1,
        stagger: 0.05,
        ease: "none",
        scrollTrigger: { trigger: ref.current, start: "top 72%", end: "bottom 68%", scrub: 0.4 },
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={ref} className="flex min-h-[70vh] items-center px-5 py-24 md:px-16 lg:py-40">
      <div className="mx-auto w-full max-w-[1240px]">
        <p className="max-w-[1120px] text-[clamp(28px,4.4vw,56px)] font-semibold leading-[1.25] tracking-[-.025em]">
          {MANIFESTO.map((chunk, ci) =>
            chunk.text.split(" ").map((word, wi) => (
              <span
                key={`${ci}-${wi}`}
                className={cn(
                  "manifesto-word inline-block opacity-[.13]",
                  chunk.accent && "grad-text font-serif italic font-normal"
                )}
              >
                {word}&nbsp;
              </span>
            ))
          )}
        </p>
      </div>
    </section>
  );
}
