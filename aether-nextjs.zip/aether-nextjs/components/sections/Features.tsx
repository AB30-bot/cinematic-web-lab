"use client";

import SectionHeading from "@/components/ui/SectionHeading";
import SpotlightCard from "@/components/ui/SpotlightCard";
import Reveal from "@/components/ui/Reveal";
import { motion } from "framer-motion";

const SATS = [
  { icon: "📬", a0: "0deg", rr: "112px", dur: "14s" },
  { icon: "🔀", a0: "120deg", rr: "112px", dur: "14s" },
  { icon: "📊", a0: "240deg", rr: "112px", dur: "14s" },
  { icon: "✅", a0: "60deg", rr: "78px", dur: "9s" },
  { icon: "✍️", a0: "240deg", rr: "78px", dur: "9s" },
];

const MEMBARS = [
  { k: "docs", w: 88 }, { k: "threads", w: 72 }, { k: "tickets", w: 95 },
  { k: "code", w: 64 }, { k: "meetings", w: 81 },
];

export default function Features() {
  return (
    <section id="features" className="px-5 py-24 md:px-16 lg:py-40">
      <div className="mx-auto max-w-[1240px]">
        <SectionHeading
          kicker="The Platform"
          title={<>An operating layer,<br />not another <em className="grad-text font-serif italic">tab.</em></>}
          sub="Aether plugs into the tools you already use and quietly takes over the work you never wanted."
        />

        <div className="grid auto-rows-[minmax(240px,auto)] grid-cols-1 gap-4 md:grid-cols-6">
          {/* Agents — hero card */}
          <Reveal className="md:col-span-4 md:row-span-2">
            <SpotlightCard className="h-full">
              <div className="mb-7 flex h-[230px] items-center justify-center">
                <div className="relative h-[230px] w-[230px]">
                  {[0, 34, 68].map((inset) => (
                    <div key={inset} className="absolute rounded-full border border-dashed border-white/[.14]" style={{ inset }} />
                  ))}
                  <div className="absolute inset-0 m-auto flex h-[54px] w-[54px] items-center justify-center rounded-full bg-grad text-xl font-extrabold text-white shadow-[0_0_44px_rgba(124,92,255,.65)]">
                    Æ
                  </div>
                  {SATS.map((s, i) => (
                    <div
                      key={i}
                      className="absolute left-1/2 top-1/2 -m-[17px] flex h-[34px] w-[34px] items-center justify-center rounded-xl border border-line2 bg-[rgba(16,16,26,.9)] text-sm shadow-lg backdrop-blur-sm"
                      style={{
                        animation: `orb ${s.dur} linear infinite`,
                        ["--a0" as string]: s.a0,
                        ["--rr" as string]: s.rr,
                      }}
                    >
                      {s.icon}
                    </div>
                  ))}
                </div>
              </div>
              <h3 className="mb-2.5 text-[19px] font-semibold tracking-[-.01em]">Autonomous agents</h3>
              <p className="max-w-[400px] text-[14.5px] leading-relaxed text-mut">
                Deploy agents that own entire workflows end-to-end — from intake to done. They plan,
                execute, verify, and report back like teammates, not scripts.
              </p>
            </SpotlightCard>
          </Reveal>

          {/* Memory */}
          <Reveal delay={0.08} className="md:col-span-2 md:row-span-2">
            <SpotlightCard className="h-full">
              <div className="mb-7 flex h-[120px] w-full flex-col justify-center gap-2.5 px-1.5">
                {MEMBARS.map((b) => (
                  <div key={b.k} className="flex items-center gap-2.5 font-mono text-[10.5px] text-dim">
                    <span className="w-14">{b.k}</span>
                    <div className="h-[5px] flex-1 overflow-hidden rounded-[3px] bg-white/[.06]">
                      <motion.i
                        className="block h-full rounded-[3px] bg-grad"
                        initial={{ width: 0 }}
                        whileInView={{ width: `${b.w}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.3, ease: [0.22, 1, 0.36, 1] }}
                      />
                    </div>
                    <span>{b.w}%</span>
                  </div>
                ))}
              </div>
              <h3 className="mb-2.5 text-[19px] font-semibold tracking-[-.01em]">Unified memory</h3>
              <p className="text-[14.5px] leading-relaxed text-mut">
                Every doc, thread, and decision becomes one searchable brain. Agents never ask what they
                should already know.
              </p>
            </SpotlightCard>
          </Reveal>

          {/* Orchestration */}
          <Reveal delay={0.12} className="md:col-span-2">
            <SpotlightCard className="h-full">
              <div className="mb-6 flex h-[110px] items-center justify-center">
                <svg viewBox="0 0 300 110" fill="none" className="h-full w-full">
                  {[
                    ["42", "55", "150", "24", "rgba(124,92,255,.55)"],
                    ["42", "55", "150", "86", "rgba(58,214,255,.5)"],
                    ["150", "24", "258", "55", "rgba(255,78,205,.5)"],
                    ["150", "86", "258", "55", "rgba(124,92,255,.4)"],
                  ].map(([x1, y1, x2, y2, stroke], i) => (
                    <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={stroke} strokeWidth="1.5"
                      strokeDasharray="6 8" style={{ animation: "dashmove 1.4s linear infinite" }} />
                  ))}
                  <circle cx="42" cy="55" r="9" fill="#0e0e18" stroke="#7c5cff" strokeWidth="2" />
                  <circle cx="150" cy="24" r="9" fill="#0e0e18" stroke="#3ad6ff" strokeWidth="2" />
                  <circle cx="150" cy="86" r="9" fill="#0e0e18" stroke="#ff4ecd" strokeWidth="2" />
                  <circle cx="258" cy="55" r="9" fill="#0e0e18" stroke="#fff" strokeWidth="2" />
                </svg>
              </div>
              <h3 className="mb-2.5 text-[19px] font-semibold tracking-[-.01em]">Realtime orchestration</h3>
              <p className="text-[14.5px] leading-relaxed text-mut">Agents coordinate like a team, not a queue — handing off context mid-task.</p>
            </SpotlightCard>
          </Reveal>

          {/* Handoff */}
          <Reveal delay={0.16} className="md:col-span-2">
            <SpotlightCard className="h-full">
              <div className="mb-6 flex h-[110px] items-center justify-center">
                <div className="flex items-center gap-3.5 text-[11px] uppercase tracking-[.1em] text-dim">
                  <span>Auto</span>
                  <div className="relative h-[34px] w-16 rounded-full border border-line2 bg-white/[.08]">
                    <i className="absolute left-[3px] top-[3px] h-[26px] w-[26px] rounded-full bg-grad shadow-[0_0_18px_rgba(124,92,255,.7)]"
                      style={{ animation: "sw 3.4s cubic-bezier(.22,1,.36,1) infinite" }} />
                  </div>
                  <span>Review</span>
                </div>
              </div>
              <h3 className="mb-2.5 text-[19px] font-semibold tracking-[-.01em]">Human handoff</h3>
              <p className="text-[14.5px] leading-relaxed text-mut">Approvals exactly where they matter. Silence everywhere they don&apos;t.</p>
            </SpotlightCard>
          </Reveal>

          {/* Security */}
          <Reveal delay={0.2} className="md:col-span-2">
            <SpotlightCard className="h-full">
              <div className="mb-6 flex h-[110px] flex-wrap items-center justify-center gap-2.5">
                {["SOC 2", "GDPR", "SSO / SAML", "RBAC", "AES-256"].map((b) => (
                  <span key={b} className="rounded-full border border-line2 bg-white/[.03] px-3 py-1.5 text-[11px] font-semibold tracking-[.12em] text-mut">
                    {b}
                  </span>
                ))}
              </div>
              <h3 className="mb-2.5 text-[19px] font-semibold tracking-[-.01em]">Enterprise-grade trust</h3>
              <p className="text-[14.5px] leading-relaxed text-mut">Your data trains no one. Region-pinned, audited, encrypted at rest and in flight.</p>
            </SpotlightCard>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
