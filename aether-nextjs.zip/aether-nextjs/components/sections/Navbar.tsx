"use client";

import { useEffect, useState } from "react";
import { NAV_LINKS } from "@/lib/data";
import { cn } from "@/lib/utils";
import MagneticButton from "@/components/ui/MagneticButton";
import Logo from "@/components/ui/Logo";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    let lastY = 0;
    const onScroll = () => {
      const y = scrollY;
      setScrolled(y > 40);
      if (y > 500 && y > lastY + 6) setHidden(true);
      else if (y < lastY - 6) setHidden(false);
      lastY = y;
    };
    addEventListener("scroll", onScroll, { passive: true });
    return () => removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={cn(
        "fixed inset-x-0 top-0 z-[9000] flex items-center justify-between border-b border-transparent px-5 py-5 transition-all duration-500 ease-out4 md:px-14",
        scrolled && "border-line bg-[rgba(6,6,10,.55)] py-3.5 backdrop-blur-xl backdrop-saturate-150",
        hidden && "-translate-y-full"
      )}
    >
      <a href="#" data-hover className="flex items-center gap-2.5 text-sm font-bold tracking-[.24em]">
        <Logo className="h-[22px] w-[22px]" />
        AETHER
      </a>
      <div className="hidden items-center gap-1.5 rounded-full border border-line bg-white/[.02] p-1.5 md:flex">
        {NAV_LINKS.map((l) => (
          <a
            key={l.href}
            href={l.href}
            data-hover
            className="rounded-full px-4 py-2 text-[13.5px] font-medium text-mut transition-colors hover:bg-white/5 hover:text-ink"
          >
            {l.label}
          </a>
        ))}
      </div>
      <div className="flex items-center gap-4">
        <a href="#" data-hover className="hidden text-[13.5px] font-medium text-mut transition-colors hover:text-ink md:block">
          Sign in
        </a>
        <MagneticButton href="#pricing" size="sm">
          Start free <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
        </MagneticButton>
      </div>
    </nav>
  );
}
