"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Logo from "@/components/ui/Logo";

gsap.registerPlugin(ScrollTrigger);

const COLS = [
  { title: "Product", links: ["Agents", "Mission Control", "Pricing", "Changelog"] },
  { title: "Company", links: ["About", "Careers", "Blog", "Press kit"] },
  { title: "Resources", links: ["Docs", "API reference", "Security", "Status"] },
];

export default function Footer() {
  const ref = useRef<HTMLElement>(null);
  const wordRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(wordRef.current, {
        yPercent: 34,
        ease: "none",
        scrollTrigger: { trigger: ref.current, start: "top bottom", end: "bottom bottom", scrub: true },
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <footer ref={ref} className="relative overflow-hidden border-t border-line">
      <div className="mx-auto grid max-w-[1240px] gap-10 px-5 py-20 md:grid-cols-[2fr_1fr_1fr_1fr] md:gap-16 md:px-16">
        <div>
          <a href="#" data-hover className="flex items-center gap-2.5 text-sm font-bold tracking-[.24em]">
            <Logo className="h-[22px] w-[22px]" /> AETHER
          </a>
          <p className="my-4 max-w-[280px] text-sm text-mut">
            The AI operating layer for teams that move at the speed of thought.
          </p>
          <div className="inline-flex items-center gap-2 rounded-full border border-line bg-white/[.02] px-4 py-2 text-xs text-mut">
            <i className="h-[7px] w-[7px] animate-[blink_2s_infinite] rounded-full bg-mint shadow-[0_0_12px_#2fe6a7]" />
            All systems operational
          </div>
        </div>
        {COLS.map((col) => (
          <div key={col.title}>
            <h5 className="mb-5 text-[11.5px] font-semibold uppercase tracking-[.24em] text-dim">{col.title}</h5>
            <ul className="flex flex-col gap-3">
              {col.links.map((l) => (
                <li key={l}>
                  <a href="#" data-hover className="group text-sm text-mut transition-colors hover:text-ink">
                    {l}
                    <span className="ml-1.5 inline-block -translate-x-1.5 opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100">→</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div
        ref={wordRef}
        aria-hidden
        className="select-none pt-10 text-center text-[clamp(90px,17vw,260px)] font-extrabold leading-[.85] tracking-[-.02em] text-transparent [background-clip:text] [-webkit-background-clip:text]"
        style={{ backgroundImage: "linear-gradient(180deg,rgba(255,255,255,.1),rgba(255,255,255,0))" }}
      >
        AETHER
      </div>

      <div className="mx-auto flex max-w-[1240px] flex-wrap items-center justify-between gap-5 border-t border-line px-5 py-6 text-[12.5px] text-dim md:px-16">
        <span>© 2026 Aether Systems, Inc. All rights reserved.</span>
        <span>Designed in orbit. Built on Earth.</span>
        <span className="flex gap-2">
          <a href="#" data-hover className="hover:text-ink">Privacy</a> ·
          <a href="#" data-hover className="hover:text-ink">Terms</a> ·
          <a href="#" data-hover className="hover:text-ink">DPA</a>
        </span>
      </div>
    </footer>
  );
}
