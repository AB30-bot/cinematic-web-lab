"use client";

import { useRef, type PointerEvent } from "react";
import { motion, useMotionValue, useSpring, useInView } from "framer-motion";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/ui/Reveal";
import Counter from "@/components/ui/Counter";
import { FEED, KPIS } from "@/lib/data";

const SIDE = ["◈ Overview", "⚡ Agents", "🧠 Memory", "📓 Playbooks", "🔌 Integrations", "🛡️ Audit log"];

export default function DashboardPreview() {
  const zone = useRef<HTMLDivElement>(null);
  const inView = useInView(zone, { once: true, margin: "-30% 0px" });
  const rx = useSpring(useMotionValue(0), { stiffness: 120, damping: 18 });
  const ry = useSpring(useMotionValue(0), { stiffness: 120, damping: 18 });

  const onPointerMove = (e: PointerEvent) => {
    const r = zone.current!.getBoundingClientRect();
    ry.set(((e.clientX - r.left) / r.width - 0.5) * 7);
    rx.set(-((e.clientY - r.top) / r.height - 0.5) * 7);
  };
  const reset = () => { rx.set(0); ry.set(0); };

  return (
    <section
      id="dashboard"
      className="px-5 py-24 md:px-16 lg:py-40"
      style={{ background: "radial-gradient(80% 60% at 50% 0%,rgba(124,92,255,.09),transparent 60%)" }}
    >
      <div className="mx-auto max-w-[1240px]">
        <SectionHeading
          center
          kicker="Mission Control"
          title={<>Every agent. One <em className="grad-text font-serif italic">pane of glass.</em></>}
          sub="Watch your autonomous workforce in real time — what's running, what shipped, what needs you."
        />
        <Reveal>
          <div ref={zone} onPointerMove={onPointerMove} onPointerLeave={reset} style={{ perspective: 1400 }}>
            <motion.div
              style={{ rotateX: rx, rotateY: ry, transformStyle: "preserve-3d" }}
              className="overflow-hidden rounded-[22px] border border-line2 bg-[rgba(10,10,16,.75)] shadow-[0_60px_140px_-40px_rgba(0,0,0,.9)] backdrop-blur-xl"
            >
              {/* window chrome */}
              <div className="flex items-center gap-2 border-b border-line px-5 py-3.5">
                <i className="h-[11px] w-[11px] rounded-full bg-[#ff5f57]" />
                <i className="h-[11px] w-[11px] rounded-full bg-[#febc2e]" />
                <i className="h-[11px] w-[11px] rounded-full bg-[#28c840]" />
                <span className="mx-auto rounded-lg bg-white/5 px-10 py-1 font-mono text-[11.5px] text-dim">
                  app.aether.os/overview
                </span>
              </div>
              <div className="grid min-h-[480px] lg:grid-cols-[200px_1fr_260px]">
                {/* sidebar */}
                <div className="hidden flex-col gap-1 border-r border-line p-4 lg:flex">
                  {SIDE.map((item, i) => (
                    <a key={item} className={`flex items-center gap-2.5 rounded-[10px] px-3 py-2 text-[13px] ${i === 0 ? "border border-violet/25 bg-violet/15 text-ink" : "text-mut"}`}>
                      {item}
                    </a>
                  ))}
                </div>
                {/* main */}
                <div className="p-6">
                  <div className="mb-5 flex items-center justify-between">
                    <h4 className="text-base font-semibold">Overview</h4>
                    <div className="flex items-center gap-2 text-[11px] font-semibold tracking-[.1em] text-mint">
                      <i className="h-1.5 w-1.5 animate-[blink_1.6s_infinite] rounded-full bg-mint shadow-[0_0_10px_#2fe6a7]" />
                      LIVE
                    </div>
                  </div>
                  <div className="mb-5 grid grid-cols-3 gap-3">
                    {KPIS.map((kpi) => (
                      <div key={kpi.label} className="rounded-[14px] border border-line bg-white/[.02] px-4 py-3.5">
                        <div className="mb-1.5 text-[10.5px] uppercase tracking-[.14em] text-dim">{kpi.label}</div>
                        <div className="text-[22px] font-bold tabular-nums tracking-[-.02em]">
                          <Counter to={kpi.value} start={inView} />
                        </div>
                        <div className="text-[10.5px] font-semibold text-mint">{kpi.delta}</div>
                      </div>
                    ))}
                  </div>
                  {/* chart */}
                  <div className="rounded-[14px] border border-line bg-white/[.015] p-4">
                    <svg viewBox="0 0 560 150" preserveAspectRatio="none" className="h-[150px] w-full">
                      <defs>
                        <linearGradient id="cg" x1="0" y1="0" x2="1" y2="0">
                          <stop stopColor="#7c5cff" /><stop offset=".6" stopColor="#3ad6ff" /><stop offset="1" stopColor="#ff4ecd" />
                        </linearGradient>
                        <linearGradient id="ag" x1="0" y1="0" x2="0" y2="1">
                          <stop stopColor="rgba(124,92,255,.28)" /><stop offset="1" stopColor="rgba(124,92,255,0)" />
                        </linearGradient>
                      </defs>
                      <g stroke="rgba(255,255,255,.05)">
                        <line x1="0" y1="30" x2="560" y2="30" /><line x1="0" y1="70" x2="560" y2="70" /><line x1="0" y1="110" x2="560" y2="110" />
                      </g>
                      <motion.path
                        d="M0,118 C60,112 90,88 140,84 C190,80 210,96 260,78 C310,60 330,64 380,44 C430,26 470,38 560,14 L560,150 L0,150 Z"
                        fill="url(#ag)"
                        initial={{ opacity: 0 }}
                        animate={inView ? { opacity: 1 } : {}}
                        transition={{ duration: 1.4, delay: 0.9 }}
                      />
                      <motion.path
                        d="M0,118 C60,112 90,88 140,84 C190,80 210,96 260,78 C310,60 330,64 380,44 C430,26 470,38 560,14"
                        stroke="url(#cg)" strokeWidth="2.5" fill="none"
                        initial={{ pathLength: 0 }}
                        animate={inView ? { pathLength: 1 } : {}}
                        transition={{ duration: 2, ease: "easeInOut" }}
                      />
                    </svg>
                  </div>
                </div>
                {/* activity feed */}
                <div className="hidden border-l border-line p-5 lg:block">
                  <div className="mb-3.5 text-[10.5px] uppercase tracking-[.16em] text-dim">Agent activity</div>
                  {FEED.map((f, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: 20 }}
                      animate={inView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.3 + i * 0.13 }}
                      className="flex gap-3 rounded-xl p-2.5 text-xs text-mut hover:bg-white/[.03]"
                    >
                      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px] text-xs" style={{ background: f.bg }}>
                        {f.icon}
                      </div>
                      <div>
                        <b className="font-semibold text-ink">{f.who}</b> {f.what}
                        <div className="mt-0.5 text-[10.5px] text-dim">{f.when}</div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
