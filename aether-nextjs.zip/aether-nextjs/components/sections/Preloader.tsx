"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence, animate } from "framer-motion";

export default function Preloader({ onDone }: { onDone: () => void }) {
  const [count, setCount] = useState(0);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    const controls = animate(0, 100, {
      duration: 1.7,
      ease: "easeInOut",
      onUpdate: (v) => setCount(Math.round(v)),
      onComplete: () => setGone(true),
    });
    return () => controls.stop();
  }, []);

  return (
    <AnimatePresence onExitComplete={onDone}>
      {!gone && (
        <motion.div
          className="fixed inset-0 z-[10000] flex flex-col items-center justify-center gap-7 bg-bg"
          exit={{ y: "-100%" }}
          transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
        >
          <motion.svg
            viewBox="0 0 48 48"
            fill="none"
            className="h-13 w-13"
            style={{ width: 52, height: 52 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 3.2, ease: "linear", repeat: Infinity }}
          >
            <path d="M24 4 L44 40 L4 40 Z" stroke="url(#pg)" strokeWidth="2.5" strokeLinejoin="round" />
            <circle cx="24" cy="28" r="5" fill="url(#pg)" />
            <defs>
              <linearGradient id="pg" x1="0" y1="0" x2="48" y2="48">
                <stop stopColor="#7c5cff" />
                <stop offset=".55" stopColor="#3ad6ff" />
                <stop offset="1" stopColor="#ff4ecd" />
              </linearGradient>
            </defs>
          </motion.svg>
          <div className="text-[13px] font-medium uppercase tabular-nums tracking-[.32em] text-mut">
            {String(count).padStart(2, "0")}
          </div>
          <div className="h-px w-44 overflow-hidden bg-line">
            <div className="h-full bg-grad" style={{ width: `${count}%` }} />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
