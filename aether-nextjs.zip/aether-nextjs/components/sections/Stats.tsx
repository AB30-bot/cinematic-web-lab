"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Counter from "@/components/ui/Counter";
import { STATS } from "@/lib/data";

export default function Stats() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-20% 0px" });

  return (
    <section className="border-y border-line px-5 py-24 md:px-16 lg:py-36">
      <div ref={ref} className="mx-auto grid max-w-[1240px] grid-cols-2 gap-8 md:grid-cols-4 md:gap-14">
        {STATS.map((stat, i) => (
          <div key={stat.label} className="py-2.5">
            <div className="flex items-baseline text-[clamp(40px,5vw,68px)] font-extrabold leading-none tabular-nums tracking-[-.04em]">
              <Counter to={stat.value} dec={stat.dec ?? 0} duration={2.2} start={inView} />
              <span className="grad-text ml-0.5 text-[.5em]">{stat.suffix}</span>
            </div>
            <div className="mt-3 text-[13px] text-mut">{stat.label}</div>
            <div className="relative mt-6 h-px overflow-hidden bg-line">
              <motion.i
                className="absolute inset-0 block origin-left bg-grad"
                initial={{ scaleX: 0 }}
                animate={inView ? { scaleX: 1 } : {}}
                transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: i * 0.12 }}
              />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
