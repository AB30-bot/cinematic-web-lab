"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/ui/Reveal";
import Counter from "@/components/ui/Counter";
import MagneticButton from "@/components/ui/MagneticButton";
import { PLANS } from "@/lib/data";
import { cn } from "@/lib/utils";

export default function Pricing() {
  const [annual, setAnnual] = useState(false);

  return (
    <section id="pricing" className="px-5 py-24 md:px-16 lg:py-40">
      <div className="mx-auto max-w-[1240px]">
        <SectionHeading
          center
          kicker="Pricing"
          title={<>Start free. Scale when <em className="grad-text font-serif italic">they do.</em></>}
          sub="Every plan includes unlimited playbooks, full audit trails, and human handoff."
        />

        {/* billing toggle */}
        <Reveal className="mb-14 flex items-center justify-center gap-3.5 text-[13.5px] text-mut">
          <button onClick={() => setAnnual(false)} data-hover className={cn("transition-colors", !annual && "font-semibold text-ink")}>
            Monthly
          </button>
          <button
            onClick={() => setAnnual(!annual)}
            data-hover
            aria-label="Toggle annual billing"
            className={cn("relative h-[29px] w-[52px] rounded-full border border-line2 transition-colors duration-400", annual ? "bg-violet/30" : "bg-white/[.08]")}
          >
            <motion.i
              className="absolute top-[3px] block h-[21px] w-[21px] rounded-full bg-ink"
              animate={{ left: annual ? 26 : 3 }}
              transition={{ type: "spring", stiffness: 500, damping: 32 }}
            />
          </button>
          <button onClick={() => setAnnual(true)} data-hover className={cn("transition-colors", annual && "font-semibold text-ink")}>
            Annual
          </button>
          <span className="rounded-full bg-mint/10 px-2.5 py-1 text-[11px] font-bold tracking-[.06em] text-mint">Save 20%</span>
        </Reveal>

        <div className="mx-auto grid max-w-[440px] gap-4 md:max-w-none md:grid-cols-3">
          {PLANS.map((plan, i) => (
            <Reveal key={plan.name} delay={i * 0.08}>
              <div
                className={cn(
                  "relative flex h-full flex-col rounded-3xl border border-line p-8 transition-all duration-500 ease-out4 hover:-translate-y-2 hover:border-line2",
                  plan.popular && "border-transparent shadow-[0_40px_110px_-30px_rgba(124,92,255,.4)]"
                )}
                style={
                  plan.popular
                    ? {
                        background:
                          "linear-gradient(180deg,rgba(18,14,34,.92),rgba(10,10,16,.96)) padding-box, linear-gradient(100deg,#7c5cff,#3ad6ff 55%,#ff4ecd) border-box",
                        border: "1px solid transparent",
                      }
                    : { background: "linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,.01))" }
                }
              >
                {plan.popular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-grad px-4 py-1.5 text-[10.5px] font-bold uppercase tracking-[.16em] text-white">
                    Most popular
                  </div>
                )}
                <div className="text-[15px] font-semibold tracking-[.02em]">{plan.name}</div>
                <div className="mt-1 text-[12.5px] text-dim">{plan.desc}</div>
                <div className="mb-1 mt-6 flex items-baseline gap-1.5">
                  {plan.monthly === null ? (
                    <span className="text-[40px] font-extrabold tracking-[-.04em]">Custom</span>
                  ) : (
                    <>
                      <span className="text-xl font-medium text-mut">$</span>
                      <span className="text-[52px] font-extrabold leading-none tabular-nums tracking-[-.04em]">
                        <Counter key={annual ? "yr" : "mo"} to={annual ? plan.annual! : plan.monthly} duration={0.55} />
                      </span>
                      <span className="text-[13px] text-dim">/user/mo</span>
                    </>
                  )}
                </div>
                <div className="min-h-4 text-[11.5px] text-dim">{annual ? plan.noteYr : plan.noteMo}</div>
                <ul className="my-7 flex flex-1 flex-col gap-3.5">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-[13.5px] text-mut">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" className="mt-[3px] shrink-0">
                        <path d="M20 6L9 17l-5-5" stroke={plan.check} strokeWidth="2.5" strokeLinecap="round" />
                      </svg>
                      {f}
                    </li>
                  ))}
                </ul>
                <MagneticButton href="#" variant={plan.popular ? "primary" : "ghost"} className="w-full">
                  {plan.cta}
                  {plan.popular && <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>}
                </MagneticButton>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
