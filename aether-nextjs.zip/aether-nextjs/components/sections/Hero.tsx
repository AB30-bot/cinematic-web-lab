"use client";

import dynamic from "next/dynamic";
import { motion, useScroll, useTransform, type Variants } from "framer-motion";
import { useRef } from "react";
import MagneticButton from "@/components/ui/MagneticButton";

const HeroScene = dynamic(() => import("@/components/three/HeroScene"), { ssr: false });

const line: Variants = {
  hidden: { y: "115%" },
  show: (i: number) => ({
    y: 0,
    transition: { duration: 1.25, ease: [0.22, 1, 0.36, 1], delay: 0.1 + i * 0.14 },
  }),
};
const fade: Variants = {
  hidden: { opacity: 0, y: 26 },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.5 + i * 0.11 },
  }),
};

const CHIPS = [
  { pos: "top-[26%] left-[7%]", dot: "#2fe6a7", strong: "Triage agent", rest: "resolved 34 tickets", depth: 26 },
  { pos: "top-[38%] right-[6%]", dot: "#3ad6ff", strong: "Release notes", rest: "drafted · awaiting review", depth: -34 },
  { pos: "bottom-[16%] left-[13%]", dot: "#ff4ecd", strong: "Pipeline watch", rest: "all systems green", depth: 18 },
];

export default function Hero({ started }: { started: boolean }) {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const sceneOpacity = useTransform(scrollYProgress, [0.4, 1], [1, 0]);
  const sceneScale = useTransform(scrollYProgress, [0, 1], [1, 0.6]);
  const contentY = useTransform(scrollYProgress, [0, 1], [0, 120]);

  return (
    <header ref={ref} className="relative flex min-h-svh items-center justify-center overflow-hidden">
      {/* ambient halo */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-[42%] z-0 aspect-square w-[min(1100px,120vw)] -translate-x-1/2 -translate-y-1/2 blur-[20px]"
        style={{
          background:
            "radial-gradient(circle at 50% 50%,rgba(124,92,255,.22),transparent 55%),radial-gradient(circle at 62% 38%,rgba(58,214,255,.12),transparent 50%),radial-gradient(circle at 40% 60%,rgba(255,78,205,.08),transparent 55%)",
        }}
      />
      {/* perspective grid floor */}
      <div
        aria-hidden
        className="absolute bottom-[-6%] left-1/2 z-0 h-[44vh] w-[160vw] -translate-x-1/2 [mask-image:radial-gradient(ellipse_60%_90%_at_50%_100%,#000_30%,transparent_75%)]"
        style={{
          transform: "translateX(-50%) perspective(700px) rotateX(66deg)",
          transformOrigin: "50% 100%",
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px)",
          backgroundSize: "56px 56px",
        }}
      />

      <motion.div style={{ opacity: sceneOpacity, scale: sceneScale }} className="absolute inset-0 z-[1]">
        <HeroScene />
      </motion.div>

      {/* floating agent chips */}
      {CHIPS.map((c, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0.7 }}
          animate={started ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, ease: "backOut", delay: 1 + i * 0.12 }}
          className={`absolute ${c.pos} z-[2] hidden items-center gap-2.5 rounded-2xl border border-line2 bg-[rgba(14,14,22,.55)] px-4.5 py-3 text-[12.5px] font-medium text-mut shadow-[0_20px_60px_-20px_rgba(0,0,0,.8)] backdrop-blur-2xl xl:flex`}
          style={{ padding: "12px 18px" }}
        >
          <span className="h-[7px] w-[7px] rounded-full" style={{ background: c.dot, boxShadow: `0 0 10px ${c.dot}` }} />
          <span>
            <b className="font-semibold text-ink">{c.strong}</b> {c.rest}
          </span>
        </motion.div>
      ))}

      <motion.div style={{ y: contentY }} className="relative z-[2] max-w-[1080px] px-6 pb-20 pt-32 text-center">
        <motion.div variants={fade} custom={0} initial="hidden" animate={started ? "show" : "hidden"}
          className="inline-flex items-center gap-2.5 rounded-full border border-line2 bg-white/[.04] py-2 pl-2.5 pr-4.5 text-[12.5px] font-medium uppercase tracking-[.08em] text-mut backdrop-blur-md"
          style={{ paddingRight: 18 }}
        >
          <span className="rounded-full bg-grad px-2.5 py-[3px] text-[10.5px] font-bold tracking-[.14em] text-white">NEW</span>
          Introducing Aether OS 2.0
        </motion.div>

        <h1 className="mt-8 text-[clamp(48px,8.6vw,118px)] font-bold leading-[1.02] tracking-[-.035em]">
          <span className="block overflow-hidden">
            <motion.span variants={line} custom={0} initial="hidden" animate={started ? "show" : "hidden"} className="block">
              Work at the
            </motion.span>
          </span>
          <span className="block overflow-hidden">
            <motion.span variants={line} custom={1} initial="hidden" animate={started ? "show" : "hidden"} className="block">
              speed of <em className="grad-text font-serif italic">thought.</em>
            </motion.span>
          </span>
        </h1>

        <motion.p variants={fade} custom={1} initial="hidden" animate={started ? "show" : "hidden"}
          className="mx-auto mt-7 max-w-[560px] text-[clamp(16px,1.6vw,19px)] leading-relaxed text-mut">
          Aether deploys autonomous agents across your stack — triaging, drafting, shipping — while your
          team focuses on what only humans can do.
        </motion.p>

        <motion.div variants={fade} custom={2} initial="hidden" animate={started ? "show" : "hidden"}
          className="mt-11 flex flex-wrap justify-center gap-4">
          <MagneticButton href="#pricing">
            Start building <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
          </MagneticButton>
          <MagneticButton href="#how" variant="ghost">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z" /></svg>
            Watch the film
          </MagneticButton>
        </motion.div>

        <motion.div variants={fade} custom={3} initial="hidden" animate={started ? "show" : "hidden"}
          className="mt-14 flex flex-wrap justify-center gap-7 text-[12.5px] tracking-[.05em] text-dim">
          {["No credit card required", "SOC 2 Type II", "Deploys in minutes"].map((t) => (
            <span key={t} className="flex items-center gap-2">
              <i className="h-[5px] w-[5px] rounded-full bg-cyan shadow-[0_0_10px_#3ad6ff]" />
              {t}
            </span>
          ))}
        </motion.div>
      </motion.div>

      {/* scroll cue */}
      <motion.div
        style={{ opacity: useTransform(scrollYProgress, [0, 0.2], [1, 0]) }}
        className="absolute bottom-7 left-1/2 z-[2] flex -translate-x-1/2 flex-col items-center gap-2.5 text-[10.5px] uppercase tracking-[.3em] text-dim"
      >
        <div className="relative h-11 w-px overflow-hidden bg-line2">
          <div className="absolute left-0 top-[-40%] h-2/5 w-full animate-[cue_2s_cubic-bezier(.22,1,.36,1)_infinite] bg-grad" />
        </div>
        Scroll
      </motion.div>
    </header>
  );
}
