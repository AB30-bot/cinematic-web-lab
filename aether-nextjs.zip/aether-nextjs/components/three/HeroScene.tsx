"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Points, PointMaterial } from "@react-three/drei";
import * as THREE from "three";

function Artifact() {
  const group = useRef<THREE.Group>(null!);
  const light = useRef<THREE.PointLight>(null!);

  useFrame(({ clock, pointer, camera }) => {
    const t = clock.getElapsedTime();
    group.current.rotation.x = t * 0.16;
    group.current.rotation.y = t * 0.11;
    light.current.position.x = Math.sin(t * 0.5) * 5;
    light.current.position.z = Math.cos(t * 0.5) * 5;
    // mouse parallax
    camera.position.x += (pointer.x * 0.6 - camera.position.x) * 0.045;
    camera.position.y += (pointer.y * 0.45 - camera.position.y) * 0.045;
    camera.lookAt(0, 0, 0);
  });

  return (
    <group ref={group}>
      <mesh>
        <torusKnotGeometry args={[1.5, 0.42, 260, 40]} />
        <meshStandardMaterial color="#15151f" metalness={0.92} roughness={0.24} />
      </mesh>
      <mesh scale={1.003}>
        <torusKnotGeometry args={[1.5, 0.42, 260, 40]} />
        <meshBasicMaterial color="#9d8cff" wireframe transparent opacity={0.05} />
      </mesh>
      <pointLight ref={light} color="#7c5cff" intensity={26} distance={30} position={[4, 3, 4]} />
    </group>
  );
}

function StarField() {
  const ref = useRef<THREE.Points>(null!);
  const positions = useMemo(() => {
    const N = 1500;
    const pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const r = 5 + Math.random() * 11;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      pos[i * 3] = r * Math.sin(ph) * Math.cos(th);
      pos[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th) * 0.6;
      pos[i * 3 + 2] = r * Math.cos(ph) - 4;
    }
    return pos;
  }, []);

  useFrame(({ clock }) => {
    ref.current.rotation.y = -clock.getElapsedTime() * 0.014;
  });

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#8f7bff"
        size={0.035}
        sizeAttenuation
        depthWrite={false}
        opacity={0.75}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  );
}

/** The floating hero artifact: torus knot + wireframe ghost + particle field. */
export default function HeroScene() {
  return (
    <Canvas
      camera={{ position: [0, 0, 7.5], fov: 45 }}
      dpr={[1, 2]}
      gl={{ alpha: true, antialias: true }}
      className="!absolute !inset-0"
    >
      <ambientLight color="#404060" intensity={0.8} />
      <pointLight color="#3ad6ff" intensity={20} distance={30} position={[-5, -2, 3]} />
      <pointLight color="#ff4ecd" intensity={16} distance={30} position={[0, 4, -4]} />
      <Artifact />
      <StarField />
    </Canvas>
  );
}
